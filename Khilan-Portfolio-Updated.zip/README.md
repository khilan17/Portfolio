# Khilan Vachhani — personal portfolio

A responsive Python/Flask portfolio with an animated, minimal landing page, a contact form stored in SQLite, and a password-protected admin inbox.

## Run locally

Python 3.10+ and Flask are required.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PORTFOLIO_ADMIN_USERNAME = "your-admin-name"
$env:PORTFOLIO_ADMIN_PASSWORD = "use-a-long-unique-password"
$env:PORTFOLIO_SECRET_KEY = "a-long-random-secret-for-sessions"
python app.py
```

Open `http://127.0.0.1:5000`. The private inbox is at `/admin`. The app creates `instance/messages.sqlite3` on first run. Set `PORTFOLIO_DATABASE` to use a different SQLite file. The admin credentials and session secret must be set outside the source code; admin sign-in stays disabled without both admin variables. For HTTPS deployments, set `PORTFOLIO_COOKIE_SECURE=1`, configure a persistent secret key, and run behind a production WSGI server rather than Flask's development server.

Optional environment settings: `PORTFOLIO_HOST`, `PORTFOLIO_PORT`, `PORTFOLIO_INSTANCE_DIR`, and `PORTFOLIO_DEBUG` (`1` only for local development).

## Contact inbox

Contact submissions are validated server-side and stored in SQLite. An authenticated admin can review messages, mark them as read, and export the inbox as CSV. Use a unique admin password and keep the database and environment credentials private.
