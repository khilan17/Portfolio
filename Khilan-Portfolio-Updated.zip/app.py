import csv
import hmac
import io
import os
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import (
    Flask,
    Response,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)


BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = Path(os.environ.get("PORTFOLIO_INSTANCE_DIR", BASE_DIR / "instance"))
DATABASE_PATH = Path(
    os.environ.get("PORTFOLIO_DATABASE", INSTANCE_DIR / "messages.sqlite3")
)

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("PORTFOLIO_SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("PORTFOLIO_COOKIE_SECURE") == "1",
    MAX_CONTENT_LENGTH=16 * 1024,
)


def get_db():
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def database():
    connection = get_db()
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_db():
    with database() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0
            )
            """
        )


def csrf_token():
    token = session.get("_csrf_token")
    if token is None:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


app.jinja_env.globals["csrf_token"] = csrf_token


def validate_csrf():
    submitted = request.form.get("_csrf_token", "")
    expected = session.get("_csrf_token", "")
    if not expected or not hmac.compare_digest(submitted, expected):
        abort(400, description="The form expired. Please reload the page and try again.")


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_authenticated"):
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)

    return wrapped


@app.after_request
def set_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; script-src 'self'; "
        "img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; "
        "base-uri 'self'"
    )
    return response


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/contact", methods=["POST"])
def contact():
    validate_csrf()
    if request.form.get("website", "").strip():
        return redirect(url_for("home", _anchor="contact"))

    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    subject = request.form.get("subject", "").strip()
    message = request.form.get("message", "").strip()

    if not name or not email or not subject or not message:
        flash("Please complete every field before sending your message.", "error")
    elif len(name) > 100 or len(email) > 254 or len(subject) > 160 or len(message) > 5000:
        flash("One or more fields are too long. Please shorten your message and try again.", "error")
    elif "@" not in email or any(character.isspace() for character in email):
        flash("Please enter a valid email address.", "error")
    else:
        with database() as connection:
            connection.execute(
                """
                INSERT INTO messages (name, email, subject, message, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    name,
                    email,
                    subject,
                    message,
                    datetime.now(timezone.utc).isoformat(timespec="seconds"),
                ),
            )
        flash("Thanks for reaching out. Your message has been received.", "success")

    return redirect(url_for("home", _anchor="contact"))


@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_authenticated"):
        return redirect(url_for("admin_inbox"))

    if request.method == "POST":
        validate_csrf()
        username = os.environ.get("PORTFOLIO_ADMIN_USERNAME")
        password = os.environ.get("PORTFOLIO_ADMIN_PASSWORD")
        submitted_username = request.form.get("username", "")
        submitted_password = request.form.get("password", "")

        if (
            username
            and password
            and hmac.compare_digest(submitted_username, username)
            and hmac.compare_digest(submitted_password, password)
        ):
            session.clear()
            session["admin_authenticated"] = True
            flash("Signed in successfully.", "success")
            return redirect(url_for("admin_inbox"))
        flash("Sign-in failed. Check your credentials and server configuration.", "error")

    return render_template(
        "admin_login.html",
        admin_configured=bool(
            os.environ.get("PORTFOLIO_ADMIN_USERNAME")
            and os.environ.get("PORTFOLIO_ADMIN_PASSWORD")
        ),
    )


@app.route("/admin/inbox")
@admin_required
def admin_inbox():
    with database() as connection:
        messages = connection.execute(
            "SELECT * FROM messages ORDER BY created_at DESC, id DESC"
        ).fetchall()
    unread_count = sum(not message["is_read"] for message in messages)
    return render_template("admin.html", messages=messages, unread_count=unread_count)


@app.route("/admin/messages/<int:message_id>/read", methods=["POST"])
@admin_required
def mark_read(message_id):
    validate_csrf()
    with database() as connection:
        result = connection.execute(
            "UPDATE messages SET is_read = 1 WHERE id = ?", (message_id,)
        )
    if result.rowcount == 0:
        abort(404)
    flash("Message marked as read.", "success")
    return redirect(url_for("admin_inbox"))


@app.route("/admin/export")
@admin_required
def export_messages():
    with database() as connection:
        messages = connection.execute(
            """
            SELECT id, name, email, subject, message, created_at, is_read
            FROM messages ORDER BY created_at DESC, id DESC
            """
        ).fetchall()

    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["ID", "Name", "Email", "Subject", "Message", "Received (UTC)", "Read"])
    for row in messages:
        writer.writerow(
            [
                row["id"],
                row["name"],
                row["email"],
                row["subject"],
                row["message"],
                row["created_at"],
                "Yes" if row["is_read"] else "No",
            ]
        )
    return Response(
        "\ufeff" + output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=portfolio-messages.csv"},
    )


@app.route("/admin/logout", methods=["POST"])
@admin_required
def admin_logout():
    validate_csrf()
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("admin_login"))


initialize_db()


if __name__ == "__main__":
    app.run(
        host=os.environ.get("PORTFOLIO_HOST", "127.0.0.1"),
        port=int(os.environ.get("PORTFOLIO_PORT", "5000")),
        debug=os.environ.get("PORTFOLIO_DEBUG") == "1",
    )
